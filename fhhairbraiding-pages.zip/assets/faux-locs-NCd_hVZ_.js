import{j as e}from"./index-CPMNjPUK.js";function i(r){const n={em:"em",h1:"h1",h2:"h2",h3:"h3",hr:"hr",img:"img",li:"li",p:"p",strong:"strong",ul:"ul",...r.components};return e.jsxs(e.Fragment,{children:[e.jsx(n.hr,{}),`
`,e.jsx(n.h2,{children:`title: "Faux Locs in Radcliff KY & Fort Knox"
description: "Professional Faux Locs by F&H Hair Braiding. Inquire today to secure your preferred style date."
slug: "faux-locs"
keywords: "Faux Locs, Hair Braiding Radcliff KY, Professional Braider Fort Knox"`}),`
`,e.jsx(n.h1,{children:"Faux Locs"}),`
`,e.jsxs(n.p,{children:["Welcome to F&H Hair Braiding, the premier destination for ",e.jsx(n.strong,{children:"Faux Locs"})," in the Radcliff, KY and Fort Knox area."]}),`
`,e.jsx(n.h2,{children:"Why Choose Our Faux Locs?"}),`
`,e.jsx(n.p,{children:"Our lead braiders specialize in flawless, tension-free Faux Locs that not only look stunning but protect your natural hair. With over 500+ crowns perfected this year, our social proof speaks for itself."}),`
`,e.jsx(n.h3,{children:"The F&H Standard:"}),`
`,e.jsxs(n.ul,{children:[`
`,e.jsxs(n.li,{children:[e.jsx(n.strong,{children:"Tension-Free Technique:"})," We prioritize the health of your scalp."]}),`
`,e.jsxs(n.li,{children:[e.jsx(n.strong,{children:"Speed & Precision:"})," Get the crown you deserve without waiting in a salon chair all day."]}),`
`,e.jsxs(n.li,{children:[e.jsx(n.strong,{children:"Premium Quality:"})," We use only the best hair extensions for all Faux Locs."]}),`
`]}),`
`,e.jsx(n.p,{children:e.jsx(n.img,{src:"/optimized-services/faux-locs.jpg",alt:"Faux Locs - Hair Braiding Radcliff KY"})}),`
`,e.jsx(n.h2,{children:"Ready to Book?"}),`
`,e.jsxs(n.p,{children:[e.jsx(n.em,{children:"High demand style!"})," Inquire today to check our studio availability and secure your slot."]}),`
`,e.jsx("button",{className:"book-now-btn",children:"Secure My Faux Locs"})]})}function o(r={}){const{wrapper:n}=r.components||{};return n?e.jsx(n,{...r,children:e.jsx(i,{...r})}):i(r)}export{o as default};
