import{j as r}from"./index-DadleoXL.js";function o(n){const e={em:"em",h1:"h1",h2:"h2",h3:"h3",hr:"hr",img:"img",li:"li",p:"p",strong:"strong",ul:"ul",...n.components};return r.jsxs(r.Fragment,{children:[r.jsx(e.h2,{children:"Expertly Crafted Cornrows & Feed-in Styles."}),`
`,r.jsx(e.p,{children:"Focus on symmetry. From simple straight backs to intricate patterns, our cornrow services emphasize symmetry and scalp health."}),`
`,r.jsx(e.hr,{}),`
`,r.jsx(e.h2,{children:`title: "Cornrows in Radcliff KY & Fort Knox"
description: "Professional Cornrows by F&H Hair Braiding. Inquire today to secure your preferred style date."
slug: "cornrows"
keywords: "Cornrows, Hair Braiding Radcliff KY, Professional Braider Fort Knox"`}),`
`,r.jsx(e.h1,{children:"Cornrows"}),`
`,r.jsxs(e.p,{children:["Welcome to F&H Hair Braiding, the premier destination for ",r.jsx(e.strong,{children:"Cornrows"})," in the Radcliff, KY and Fort Knox area."]}),`
`,r.jsx(e.h2,{children:"Why Choose Our Cornrows?"}),`
`,r.jsx(e.p,{children:"Our lead braiders specialize in flawless, tension-free Cornrows that not only look stunning but protect your natural hair. With over 500+ crowns perfected this year, our social proof speaks for itself."}),`
`,r.jsx(e.h3,{children:"The F&H Standard:"}),`
`,r.jsxs(e.ul,{children:[`
`,r.jsxs(e.li,{children:[r.jsx(e.strong,{children:"Tension-Free Technique:"})," We prioritize the health of your scalp."]}),`
`,r.jsxs(e.li,{children:[r.jsx(e.strong,{children:"Speed & Precision:"})," Get the crown you deserve without waiting in a salon chair all day."]}),`
`,r.jsxs(e.li,{children:[r.jsx(e.strong,{children:"Premium Quality:"})," We use only the best hair extensions for all Cornrows."]}),`
`]}),`
`,r.jsx(e.p,{children:r.jsx(e.img,{src:"/optimized-services/cornrows.jpg",alt:"Cornrows - Hair Braiding Radcliff KY"})}),`
`,r.jsx(e.h2,{children:"Ready to Book?"}),`
`,r.jsxs(e.p,{children:[r.jsx(e.em,{children:"High demand style!"})," Inquire today to check our studio availability and secure your slot."]}),`
`,r.jsx("button",{className:"book-now-btn",children:"Secure My Cornrows"})]})}function i(n={}){const{wrapper:e}=n.components||{};return e?r.jsx(e,{...n,children:r.jsx(o,{...n})}):o(n)}export{i as default};
