import{j as r}from"./index-BdZkMjwL.js";function n(e){const i={em:"em",h1:"h1",h2:"h2",h3:"h3",hr:"hr",img:"img",li:"li",p:"p",strong:"strong",ul:"ul",...e.components};return r.jsxs(r.Fragment,{children:[r.jsx(i.hr,{}),`
`,r.jsx(i.h2,{children:`title: "Tribal Braids in Radcliff KY & Fort Knox"
description: "Professional Tribal Braids by F&H Hair Braiding. Inquire today to secure your preferred style date."
slug: "tribal-braids"
keywords: "Tribal Braids, Hair Braiding Radcliff KY, Professional Braider Fort Knox"`}),`
`,r.jsx(i.h1,{children:"Tribal Braids"}),`
`,r.jsxs(i.p,{children:["Welcome to F&H Hair Braiding, the premier destination for ",r.jsx(i.strong,{children:"Tribal Braids"})," in the Radcliff, KY and Fort Knox area."]}),`
`,r.jsx(i.h2,{children:"Why Choose Our Tribal Braids?"}),`
`,r.jsx(i.p,{children:"Our lead braiders specialize in flawless, tension-free Tribal Braids that not only look stunning but protect your natural hair. With over 500+ crowns perfected this year, our social proof speaks for itself."}),`
`,r.jsx(i.h3,{children:"The F&H Standard:"}),`
`,r.jsxs(i.ul,{children:[`
`,r.jsxs(i.li,{children:[r.jsx(i.strong,{children:"Tension-Free Technique:"})," We prioritize the health of your scalp."]}),`
`,r.jsxs(i.li,{children:[r.jsx(i.strong,{children:"Speed & Precision:"})," Get the crown you deserve without waiting in a salon chair all day."]}),`
`,r.jsxs(i.li,{children:[r.jsx(i.strong,{children:"Premium Quality:"})," We use only the best hair extensions for all Tribal Braids."]}),`
`]}),`
`,r.jsx(i.p,{children:r.jsx(i.img,{src:"/optimized-services/tribal-braids.jpg",alt:"Tribal Braids - Hair Braiding Radcliff KY"})}),`
`,r.jsx(i.h2,{children:"Ready to Book?"}),`
`,r.jsxs(i.p,{children:[r.jsx(i.em,{children:"High demand style!"})," Inquire today to check our studio availability and secure your slot."]}),`
`,r.jsx("button",{className:"book-now-btn",children:"Secure My Tribal Braids"})]})}function a(e={}){const{wrapper:i}=e.components||{};return i?r.jsx(i,{...e,children:r.jsx(n,{...e})}):n(e)}export{a as default};
