import{j as s}from"./index-DadleoXL.js";function e(n){const i={em:"em",h1:"h1",h2:"h2",h3:"h3",hr:"hr",img:"img",li:"li",p:"p",strong:"strong",ul:"ul",...n.components};return s.jsxs(s.Fragment,{children:[s.jsx(i.hr,{}),`
`,s.jsx(i.h2,{children:`title: "Passion Twists in Radcliff KY & Fort Knox"
description: "Professional Passion Twists by F&H Hair Braiding. Inquire today to secure your preferred style date."
slug: "passion-twists"
keywords: "Passion Twists, Hair Braiding Radcliff KY, Professional Braider Fort Knox"`}),`
`,s.jsx(i.h1,{children:"Passion Twists"}),`
`,s.jsxs(i.p,{children:["Welcome to F&H Hair Braiding, the premier destination for ",s.jsx(i.strong,{children:"Passion Twists"})," in the Radcliff, KY and Fort Knox area."]}),`
`,s.jsx(i.h2,{children:"Why Choose Our Passion Twists?"}),`
`,s.jsx(i.p,{children:"Our lead braiders specialize in flawless, tension-free Passion Twists that not only look stunning but protect your natural hair. With over 500+ crowns perfected this year, our social proof speaks for itself."}),`
`,s.jsx(i.h3,{children:"The F&H Standard:"}),`
`,s.jsxs(i.ul,{children:[`
`,s.jsxs(i.li,{children:[s.jsx(i.strong,{children:"Tension-Free Technique:"})," We prioritize the health of your scalp."]}),`
`,s.jsxs(i.li,{children:[s.jsx(i.strong,{children:"Speed & Precision:"})," Get the crown you deserve without waiting in a salon chair all day."]}),`
`,s.jsxs(i.li,{children:[s.jsx(i.strong,{children:"Premium Quality:"})," We use only the best hair extensions for all Passion Twists."]}),`
`]}),`
`,s.jsx(i.p,{children:s.jsx(i.img,{src:"/optimized-services/passion-twists.jpg",alt:"Passion Twists - Hair Braiding Radcliff KY"})}),`
`,s.jsx(i.h2,{children:"Ready to Book?"}),`
`,s.jsxs(i.p,{children:[s.jsx(i.em,{children:"High demand style!"})," Inquire today to check our studio availability and secure your slot."]}),`
`,s.jsx("button",{className:"book-now-btn",children:"Secure My Passion Twists"})]})}function t(n={}){const{wrapper:i}=n.components||{};return i?s.jsx(i,{...n,children:s.jsx(e,{...n})}):e(n)}export{t as default};
