import{j as e}from"./index-DadleoXL.js";function o(t){const n={h2:"h2",h3:"h3",p:"p",...t.components};return e.jsxs(e.Fragment,{children:[e.jsx(n.h2,{children:"Sophisticated Braided Ponytails & High-Crown Styles."}),`
`,e.jsx(n.p,{children:"Focus on structural integrity. Perfect for events or daily elegance, our braided ponytails are secured for longevity without compromising comfort."}),`
`,e.jsx(n.h3,{children:"The Process"}),`
`,e.jsx(n.p,{children:"We begin with a thorough wash and conditioning, followed by the careful construction of your high-crown masterpiece."})]})}function i(t={}){const{wrapper:n}=t.components||{};return n?e.jsx(n,{...t,children:e.jsx(o,{...t})}):o(t)}export{i as default};
