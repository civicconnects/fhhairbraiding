import{j as e}from"./index-BdZkMjwL.js";function n(i){const r={em:"em",h1:"h1",h2:"h2",h3:"h3",hr:"hr",img:"img",li:"li",p:"p",strong:"strong",ul:"ul",...i.components};return e.jsxs(e.Fragment,{children:[e.jsx(r.hr,{}),`
`,e.jsx(r.h2,{children:`title: "Crochet Braids in Radcliff KY & Fort Knox"
description: "Professional Crochet Braids by F&H Hair Braiding. Inquire today to secure your preferred style date."
slug: "crochet-braids"
keywords: "Crochet Braids, Hair Braiding Radcliff KY, Professional Braider Fort Knox"`}),`
`,e.jsx(r.h1,{children:"Crochet Braids"}),`
`,e.jsxs(r.p,{children:["Welcome to F&H Hair Braiding, the premier destination for ",e.jsx(r.strong,{children:"Crochet Braids"})," in the Radcliff, KY and Fort Knox area."]}),`
`,e.jsx(r.h2,{children:"Why Choose Our Crochet Braids?"}),`
`,e.jsx(r.p,{children:"Our lead braiders specialize in flawless, tension-free Crochet Braids that not only look stunning but protect your natural hair. With over 500+ crowns perfected this year, our social proof speaks for itself."}),`
`,e.jsx(r.h3,{children:"The F&H Standard:"}),`
`,e.jsxs(r.ul,{children:[`
`,e.jsxs(r.li,{children:[e.jsx(r.strong,{children:"Tension-Free Technique:"})," We prioritize the health of your scalp."]}),`
`,e.jsxs(r.li,{children:[e.jsx(r.strong,{children:"Speed & Precision:"})," Get the crown you deserve without waiting in a salon chair all day."]}),`
`,e.jsxs(r.li,{children:[e.jsx(r.strong,{children:"Premium Quality:"})," We use only the best hair extensions for all Crochet Braids."]}),`
`]}),`
`,e.jsx(r.p,{children:e.jsx(r.img,{src:"/optimized-services/crochet-braids.jpg",alt:"Crochet Braids - Hair Braiding Radcliff KY"})}),`
`,e.jsx(r.h2,{children:"Ready to Book?"}),`
`,e.jsxs(r.p,{children:[e.jsx(r.em,{children:"High demand style!"})," Inquire today to check our studio availability and secure your slot."]}),`
`,e.jsx("button",{className:"book-now-btn",children:"Secure My Crochet Braids"})]})}function o(i={}){const{wrapper:r}=i.components||{};return r?e.jsx(r,{...i,children:e.jsx(n,{...i})}):n(i)}export{o as default};
