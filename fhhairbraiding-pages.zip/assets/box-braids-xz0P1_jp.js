import{j as n}from"./index-CPMNjPUK.js";function i(r){const e={em:"em",h1:"h1",h2:"h2",h3:"h3",hr:"hr",img:"img",li:"li",p:"p",strong:"strong",ul:"ul",...r.components};return n.jsxs(n.Fragment,{children:[n.jsx(e.h2,{children:"Precision Box Braids: Classic, Clean, and Long-Lasting."}),`
`,n.jsx(e.p,{children:"Focus on parting and neatness. Our signature box braids are known for razor-sharp parts and consistent density, designed to last 6-8 weeks while protecting your natural hair."}),`
`,n.jsx(e.hr,{}),`
`,n.jsx(e.h2,{children:`title: "Box Braids in Radcliff KY & Fort Knox"
description: "Professional Box Braids by F&H Hair Braiding. Inquire today to secure your preferred style date."
slug: "box-braids"
keywords: "Box Braids, Hair Braiding Radcliff KY, Professional Braider Fort Knox"`}),`
`,n.jsx(e.h1,{children:"Box Braids"}),`
`,n.jsxs(e.p,{children:["Welcome to F&H Hair Braiding, the premier destination for ",n.jsx(e.strong,{children:"Box Braids"})," in the Radcliff, KY and Fort Knox area."]}),`
`,n.jsx(e.h2,{children:"Why Choose Our Box Braids?"}),`
`,n.jsx(e.p,{children:"Our lead braiders specialize in flawless, tension-free Box Braids that not only look stunning but protect your natural hair. With over 500+ crowns perfected this year, our social proof speaks for itself."}),`
`,n.jsx(e.h3,{children:"The F&H Standard:"}),`
`,n.jsxs(e.ul,{children:[`
`,n.jsxs(e.li,{children:[n.jsx(e.strong,{children:"Tension-Free Technique:"})," We prioritize the health of your scalp."]}),`
`,n.jsxs(e.li,{children:[n.jsx(e.strong,{children:"Speed & Precision:"})," Get the crown you deserve without waiting in a salon chair all day."]}),`
`,n.jsxs(e.li,{children:[n.jsx(e.strong,{children:"Premium Quality:"})," We use only the best hair extensions for all Box Braids."]}),`
`]}),`
`,n.jsx(e.p,{children:n.jsx(e.img,{src:"/optimized-services/box-braids.jpg",alt:"Box Braids - Hair Braiding Radcliff KY"})}),`
`,n.jsx(e.h2,{children:"Ready to Book?"}),`
`,n.jsxs(e.p,{children:[n.jsx(e.em,{children:"High demand style!"})," Inquire today to check our studio availability and secure your slot."]}),`
`,n.jsx("button",{className:"book-now-btn",children:"Secure My Box Braids"})]})}function o(r={}){const{wrapper:e}=r.components||{};return e?n.jsx(e,{...r,children:n.jsx(i,{...r})}):i(r)}export{o as default};
